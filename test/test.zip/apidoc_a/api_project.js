define({
  "name": "yyb_parks",
  "version": "1.0.0",
  "description": "yyb_parks interface",
  "title": "yyb_parks interface",
  "url": "http://116.62.190.147:8888",
  "sampleUrl": "http://116.62.190.147:8888",
  "order": [
    "auth",
    "member",
    "test",
    "payment",
    "login",
    "inlog",
    "outlog",
    "getOrderByLpn",
    "tradeCreate",
    "aliSpQr",
    "callNotify",
    "refund",
    "result"
  ],
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-23T11:19:53.432Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
