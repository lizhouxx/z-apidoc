define({ "api": [
  {
    "type": "json2",
    "url": "/auth/memberPhone/login",
    "title": "手机号短信验证码登",
    "description": "<p>手机号短信验证码登</p>",
    "name": "login",
    "group": "member",
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "phoneNum",
            "description": "<p>phoneNum</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "vcode",
            "description": "<p>vcode</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "channel",
            "description": "<p>渠道(1：QQ；2：微信；3：支付宝；4：APP)</p>"
          }
        ]
      }
    },
    "filename": "a/t.java",
    "groupTitle": "member",
    "sampleRequest": [
      {
        "url": "http://116.62.190.147:8888/auth/memberPhone/login"
      }
    ]
  },
  {
    "type": "post",
    "url": "/payment/order/getOrderByLpn",
    "title": "订单查询接口↑",
    "description": "<p>提供根据车牌获取当前车辆的订单</p>",
    "name": "getOrderByLpn1",
    "group": "payment",
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "plateId",
            "description": "<p>车牌号码</p>"
          }
        ]
      }
    },
    "filename": "a/t.java",
    "groupTitle": "payment",
    "sampleRequest": [
      {
        "url": "http://116.62.190.147:8888/payment/order/getOrderByLpn"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Authorization",
            "description": "<p>鉴权信息</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "success": [
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>响应码</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>响应信息</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "data",
            "description": "<p>数据</p>"
          }
        ]
      }
    }
  },
  {
    "type": "json",
    "url": "/payment/order/getOrderByLpn",
    "title": "订单查询接口↑",
    "description": "<p>提供根据车牌获取当前车辆的订单</p>",
    "name": "getOrderByLpn12",
    "group": "payment",
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "plateId",
            "description": "<p>车牌号码</p>"
          }
        ]
      }
    },
    "filename": "a/t.java",
    "groupTitle": "payment",
    "sampleRequest": [
      {
        "url": "http://116.62.190.147:8888/payment/order/getOrderByLpn"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Authorization",
            "description": "<p>鉴权信息</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "success": [
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>响应码</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>响应信息</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "data",
            "description": "<p>数据</p>"
          }
        ]
      }
    }
  },
  {
    "type": "json2",
    "url": "/payment/order/getOrderByLpn",
    "title": "订单查询接口↑",
    "description": "<p>提供根据车牌获取当前车辆的订单</p>",
    "name": "getOrderByLpn3",
    "group": "payment",
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "plateId",
            "description": "<p>车牌号码</p>"
          }
        ]
      }
    },
    "filename": "a/t.java",
    "groupTitle": "payment",
    "sampleRequest": [
      {
        "url": "http://116.62.190.147:8888/payment/order/getOrderByLpn"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Authorization",
            "description": "<p>鉴权信息</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "success": [
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>响应码</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "msg",
            "description": "<p>响应信息</p>"
          },
          {
            "group": "success",
            "type": "String",
            "optional": false,
            "field": "data",
            "description": "<p>数据</p>"
          }
        ]
      }
    }
  }
] });
