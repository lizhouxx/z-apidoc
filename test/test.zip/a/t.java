﻿    /**
     * @api {post} /payment/order/getOrderByLpn 订单查询接口↑
     * @apiDescription  提供根据车牌获取当前车辆的订单
     * @apiName getOrderByLpn1
     * @apiGroup payment
     * @apiVersion 1.0.0
     * 
     * @apiParam {String} plateId   车牌号码
     * @apiUse auth_a_succ_msg
     */

    /**
     * @api {json} /payment/order/getOrderByLpn 订单查询接口↑
     * @apiDescription  提供根据车牌获取当前车辆的订单
     * @apiName getOrderByLpn12
     * @apiGroup payment
     * @apiVersion 1.0.0
     * 
     * @apiParam {String} plateId   车牌号码
     * @apiUse auth_a_succ_msg
     */


    /**
     * @api {json2} /payment/order/getOrderByLpn 订单查询接口↑
     * @apiDescription  提供根据车牌获取当前车辆的订单
     * @apiName getOrderByLpn3
     * @apiGroup payment
     * @apiVersion 1.0.0
     * 
     * @apiParam {String} plateId   车牌号码
     * @apiUse auth_a_succ_msg
     */
  /**
     * @apiDefine auth_a_succ_msg 全局配置auth鉴权请求头和成功响应信息
     * 
     * @apiHeader  {String}  Authorization 鉴权信息
     * @apiSuccess (success) {String}  code     响应码
     * @apiSuccess (success) {String}  msg      响应信息
     * @apiSuccess (success) {String}  data      数据
     */
     
       /**
     * @api {json2} /auth/memberPhone/login 手机号短信验证码登
     * @apiDescription  手机号短信验证码登
     * @apiName login
     * @apiGroup member
     * @apiVersion 1.0.0
     * 
     * @apiParam {String} phoneNum phoneNum
     * @apiParam {String} vcode  vcode
     * @apiParam {String} channel  渠道(1：QQ；2：微信；3：支付宝；4：APP)
     */