

function init_do_fill(){
  //����ʱͬ������ͬ����ֵ
	$("[data-sample-request-param-name],[data-sample-request-header-name]").change(function(){
		
		    var do_fill=window.localStorage.do_fill;
		    var history_enable=window.localStorage.history_enable && window.localStorage.history_enable==1;
	      if(!history_enable ||!do_fill || do_fill==0) return;
    	  
    	  var name=$(this).attr('data-sample-request-param-name');
    	  if(!name)name=$(this).attr('data-sample-request-header-name');
    	  
    	  if(name=='JSON__STR') return;
    	  
    	  $in_=$("[data-sample-request-param-name='"+name+"'],[data-sample-request-header-name='"+name+"']");

    	  if(do_fill==1)
    	  {
    	  	$in_.val(this.value)
    	  }
    	  else if(do_fill==2)
    	  {
    	  	$in_.each(function()
    	  	{
    	  		if($(this).val()=='')
    	  		  $(this).val(this.value)
    	  	});
    	  }
	})
}

//��������ʱ�������id����
//p��ѡ�񵥸��ӿڣ�articleԪ�أ�
function cacheInput(p) {
	  var history_enable=window.localStorage.history_enable && window.localStorage.history_enable==1;
	  if(!history_enable) return;
    var info={};
    $(p+" [data-sample-request-param-name],[data-sample-request-header-name]").each(function()
    {
    	  if(this.id && this.id!='' && this.value!='')
    	  {
    	  	if(this.tagName=='INPUT')
    	  	{
            if(this.type=='text'){
                info[this.id]={"type":"text","value":this.value}
            }
    	  	}
    	  	else if(this.tagName=='TEXTAREA')
    	    {
            info[this.id]={"type":"textarea","value":this.value}
    	    }
    	  }
    })
    
    var history=window.localStorage.history?JSON.parse(window.localStorage.history):{};
    history[p]=info;
    window.localStorage.history=JSON.stringify(history)
}

//ˢ��ҳ�水Ĭ��ֵ�ͻ��� ��ʼ��

function initInput()
{
	  var history_enable=window.localStorage.history_enable && window.localStorage.history_enable==1;
	  if(!history_enable) return;
    var history=window.localStorage.history?$.parseJSON(window.localStorage.history):{};
    var default_=window.localStorage.default?$.parseJSON(window.localStorage.default):{};

    for(p in history){
    	  var info=history[p]
    	  for(id in info)
    	  {
    	  	var $in_=$(p+' #'+id)
    	  	var type=info[id].type
    	  	var value=info[id].value
    	  	
    	  	if(type=='text')
    	  	{
    	  		$in_.val(value)
    	  	}
    	  	/*
    	  	else if(type=='radio')
    	  	{
    	  			$in_.attr('checked','checked')
    	    }
    	  	else if(type=='checkbox')
    	  	{
    	  			$in_.attr('checked','checked')
    	    }
    	    */
    	  	else if(type=='textarea')
    	  	{
    	  			$in_.val(value)
    	    }
    	    
    	  }
    }
    
    for(name in default_)
    {
        setByRequestName(name,default_[name])
    }
     init_do_fill();
  
}
function setByRequestName(name,value)
{
    	  $in_=$("[data-sample-request-param-name='"+name+"'],[data-sample-request-header-name='"+name+"']");
    
    	  if(value)
    	  {
    	  	$in_.each(function(){
    	  		if($(this).val()=='')$(this).val(value)
    	  	});
    	  }
}
